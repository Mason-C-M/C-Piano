﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Piano
{
    public partial class Piano : Form
    {
        public Piano()
        {
            InitializeComponent();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void Piano_Load(object sender, EventArgs e)
        {

        }

        private void Piano_KeyUp(object sender, KeyEventArgs e)
        {
            //REGULAR KEYS
            if (e.KeyCode == Keys.A)
            {
                picC.BackColor = Color.White;
            }

            if (e.KeyCode == Keys.S)
            {
                picD.BackColor = Color.White;
            }

            if (e.KeyCode == Keys.D)
            {
                picE.BackColor = Color.White;
            }

            if (e.KeyCode == Keys.F)
            {
                picF.BackColor = Color.White;
            }

            if (e.KeyCode == Keys.G)
            {
                picG.BackColor = Color.White;
            }

            if (e.KeyCode == Keys.H)
            {
                picA.BackColor = Color.White;
            }

            if (e.KeyCode == Keys.J)
            {
                picB.BackColor = Color.White;
            }

            //SHARP KEYS
            if (e.KeyCode == Keys.Q)
            {
                picCSharp.BackColor = Color.Black;
            }

            if (e.KeyCode == Keys.W)
            {
                picDSharp.BackColor = Color.Black;
            }

            if (e.KeyCode == Keys.E)
            {
                picFSharp.BackColor = Color.Black;
            }

            if (e.KeyCode == Keys.R)
            {
                picGSharp.BackColor = Color.Black;
            }

            if (e.KeyCode == Keys.T)
            {
                picASharp.BackColor = Color.Black;
            }
        }

        private void Piano_KeyDown(object sender, KeyEventArgs e)
        {

            //REGULAR KEYS
            if (e.KeyCode == Keys.A)
            {
                picC.BackColor = Color.Teal;
                SoundPlayer audio = new SoundPlayer(Properties.Resources.C);
                audio.Play();
            }

            if (e.KeyCode == Keys.S)
            {
                picD.BackColor = Color.Teal;
                SoundPlayer audio = new SoundPlayer(Properties.Resources.D);
                audio.Play();
            }

            if (e.KeyCode == Keys.D)
            {
                picE.BackColor = Color.Teal;
                SoundPlayer audio = new SoundPlayer(Properties.Resources.E);
                audio.Play();
            }

            if (e.KeyCode == Keys.F)
            {
                picF.BackColor = Color.Teal;
                SoundPlayer audio = new SoundPlayer(Properties.Resources.F);
                audio.Play();
            }

            if (e.KeyCode == Keys.G)
            {
                picG.BackColor = Color.Teal;
                SoundPlayer audio = new SoundPlayer(Properties.Resources.G);
                audio.Play();
            }

            if (e.KeyCode == Keys.H)
            {
                picA.BackColor = Color.Teal;
                SoundPlayer audio = new SoundPlayer(Properties.Resources.A);
                audio.Play();
            }

            if (e.KeyCode == Keys.J)
            {
                picB.BackColor = Color.Teal;
                SoundPlayer audio = new SoundPlayer(Properties.Resources.B);
                audio.Play();
            }

            //SHARP KEYS
            if(e.KeyCode == Keys.Q)
            {
                picCSharp.BackColor = Color.LightBlue;
                SoundPlayer audio = new SoundPlayer(Properties.Resources.C_);
                audio.Play();
            }

            if (e.KeyCode == Keys.W)
            {
                picDSharp.BackColor = Color.LightBlue;
                SoundPlayer audio = new SoundPlayer(Properties.Resources.D_);
                audio.Play();
            }

            if (e.KeyCode == Keys.E)
            {
                picFSharp.BackColor = Color.LightBlue;
                SoundPlayer audio = new SoundPlayer(Properties.Resources.F_);
                audio.Play();
            }

            if (e.KeyCode == Keys.R)
            {
                picGSharp.BackColor = Color.LightBlue;
                SoundPlayer audio = new SoundPlayer(Properties.Resources.G_);
                audio.Play();
            }

            if (e.KeyCode == Keys.T)
            {
                picASharp.BackColor = Color.LightBlue;
                SoundPlayer audio = new SoundPlayer(Properties.Resources.B_);
                audio.Play();
            }
        }
    }
}
