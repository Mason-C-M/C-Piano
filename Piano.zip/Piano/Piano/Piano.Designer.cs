﻿namespace Piano
{
    partial class Piano
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picC = new System.Windows.Forms.PictureBox();
            this.picG = new System.Windows.Forms.PictureBox();
            this.picA = new System.Windows.Forms.PictureBox();
            this.picF = new System.Windows.Forms.PictureBox();
            this.picE = new System.Windows.Forms.PictureBox();
            this.picD = new System.Windows.Forms.PictureBox();
            this.picB = new System.Windows.Forms.PictureBox();
            this.picCSharp = new System.Windows.Forms.PictureBox();
            this.picDSharp = new System.Windows.Forms.PictureBox();
            this.picFSharp = new System.Windows.Forms.PictureBox();
            this.picGSharp = new System.Windows.Forms.PictureBox();
            this.picASharp = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCSharp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDSharp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFSharp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGSharp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picASharp)).BeginInit();
            this.SuspendLayout();
            // 
            // picC
            // 
            this.picC.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picC.Location = new System.Drawing.Point(0, 0);
            this.picC.Name = "picC";
            this.picC.Size = new System.Drawing.Size(73, 389);
            this.picC.TabIndex = 0;
            this.picC.TabStop = false;
            // 
            // picG
            // 
            this.picG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picG.Location = new System.Drawing.Point(275, 0);
            this.picG.Name = "picG";
            this.picG.Size = new System.Drawing.Size(73, 389);
            this.picG.TabIndex = 1;
            this.picG.TabStop = false;
            // 
            // picA
            // 
            this.picA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picA.Location = new System.Drawing.Point(344, 0);
            this.picA.Name = "picA";
            this.picA.Size = new System.Drawing.Size(73, 389);
            this.picA.TabIndex = 2;
            this.picA.TabStop = false;
            // 
            // picF
            // 
            this.picF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picF.Location = new System.Drawing.Point(206, 0);
            this.picF.Name = "picF";
            this.picF.Size = new System.Drawing.Size(73, 389);
            this.picF.TabIndex = 3;
            this.picF.TabStop = false;
            // 
            // picE
            // 
            this.picE.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picE.Location = new System.Drawing.Point(137, 0);
            this.picE.Name = "picE";
            this.picE.Size = new System.Drawing.Size(73, 389);
            this.picE.TabIndex = 4;
            this.picE.TabStop = false;
            // 
            // picD
            // 
            this.picD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picD.Location = new System.Drawing.Point(68, 0);
            this.picD.Name = "picD";
            this.picD.Size = new System.Drawing.Size(73, 389);
            this.picD.TabIndex = 5;
            this.picD.TabStop = false;
            // 
            // picB
            // 
            this.picB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picB.Location = new System.Drawing.Point(414, 0);
            this.picB.Name = "picB";
            this.picB.Size = new System.Drawing.Size(73, 389);
            this.picB.TabIndex = 6;
            this.picB.TabStop = false;
            // 
            // picCSharp
            // 
            this.picCSharp.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.picCSharp.Location = new System.Drawing.Point(47, 0);
            this.picCSharp.Name = "picCSharp";
            this.picCSharp.Size = new System.Drawing.Size(38, 244);
            this.picCSharp.TabIndex = 7;
            this.picCSharp.TabStop = false;
            // 
            // picDSharp
            // 
            this.picDSharp.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.picDSharp.Location = new System.Drawing.Point(121, 0);
            this.picDSharp.Name = "picDSharp";
            this.picDSharp.Size = new System.Drawing.Size(38, 244);
            this.picDSharp.TabIndex = 9;
            this.picDSharp.TabStop = false;
            // 
            // picFSharp
            // 
            this.picFSharp.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.picFSharp.Location = new System.Drawing.Point(260, 0);
            this.picFSharp.Name = "picFSharp";
            this.picFSharp.Size = new System.Drawing.Size(38, 244);
            this.picFSharp.TabIndex = 10;
            this.picFSharp.TabStop = false;
            // 
            // picGSharp
            // 
            this.picGSharp.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.picGSharp.Location = new System.Drawing.Point(324, 0);
            this.picGSharp.Name = "picGSharp";
            this.picGSharp.Size = new System.Drawing.Size(38, 244);
            this.picGSharp.TabIndex = 11;
            this.picGSharp.TabStop = false;
            // 
            // picASharp
            // 
            this.picASharp.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.picASharp.Location = new System.Drawing.Point(396, 0);
            this.picASharp.Name = "picASharp";
            this.picASharp.Size = new System.Drawing.Size(38, 244);
            this.picASharp.TabIndex = 12;
            this.picASharp.TabStop = false;
            // 
            // Piano
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 390);
            this.Controls.Add(this.picASharp);
            this.Controls.Add(this.picGSharp);
            this.Controls.Add(this.picFSharp);
            this.Controls.Add(this.picDSharp);
            this.Controls.Add(this.picCSharp);
            this.Controls.Add(this.picB);
            this.Controls.Add(this.picD);
            this.Controls.Add(this.picE);
            this.Controls.Add(this.picF);
            this.Controls.Add(this.picA);
            this.Controls.Add(this.picG);
            this.Controls.Add(this.picC);
            this.Name = "Piano";
            this.Text = "Piano";
            this.Load += new System.EventHandler(this.Piano_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Piano_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Piano_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.picC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCSharp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDSharp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFSharp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picGSharp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picASharp)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picC;
        private System.Windows.Forms.PictureBox picG;
        private System.Windows.Forms.PictureBox picA;
        private System.Windows.Forms.PictureBox picF;
        private System.Windows.Forms.PictureBox picE;
        private System.Windows.Forms.PictureBox picD;
        private System.Windows.Forms.PictureBox picB;
        private System.Windows.Forms.PictureBox picCSharp;
        private System.Windows.Forms.PictureBox picDSharp;
        private System.Windows.Forms.PictureBox picFSharp;
        private System.Windows.Forms.PictureBox picGSharp;
        private System.Windows.Forms.PictureBox picASharp;
    }
}

